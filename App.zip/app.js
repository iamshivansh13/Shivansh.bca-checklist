// BCA Syllabus Checklist — original implementation by Shivansh Maurya
// Add your own Firebase web-app config below to enable Google login + cloud sync.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore, doc, getDoc, setDoc } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "PASTE_YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  appId: "YOUR_FIREBASE_APP_ID"
};
const firebaseReady = !Object.values(firebaseConfig).some(v => String(v).includes("PASTE_") || String(v).includes("YOUR_"));
let auth = null, db = null, currentUser = null;
if (firebaseReady) {
  const app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
}

const syllabus = {
  "1": {
    "1": [
      {name:"Computer Fundamentals", code:"BCA-101", units:[
        ["Introduction to Computers","Characteristics and generations of computers","Types of computers","Computer organization and functional units","Input and output devices"],
        ["Number Systems","Binary, decimal, octal and hexadecimal systems","Number system conversions","Binary arithmetic","Complements and codes"],
        ["Computer Memory","Primary and secondary memory","RAM and ROM","Cache memory","Storage devices"],
        ["Software Concepts","System and application software","Operating systems overview","Language translators","Programming language generations"]
      ]},
      {name:"Programming in C", code:"BCA-102", units:[
        ["C Basics","History and features of C","Structure of a C program","Variables, constants and data types","Operators and expressions"],
        ["Control Statements","if, if-else and nested if","switch statement","for, while and do-while loops","break and continue"],
        ["Arrays and Strings","One-dimensional arrays","Two-dimensional arrays","String handling basics","Array operations"],
        ["Functions and Pointers","Function declaration and definition","Call by value and address","Recursion","Pointers and pointer arithmetic"]
      ]},
      {name:"Mathematics", code:"BCA-103", units:[
        ["Set Theory","Sets and representations","Types of sets","Operations on sets","Relations and functions"],
        ["Matrices","Types of matrices","Matrix operations","Determinants","Inverse of a matrix"],
        ["Differential Calculus","Limits and continuity","Differentiation rules","Applications of derivatives","Maxima and minima"],
        ["Statistics","Measures of central tendency","Mean, median and mode","Dispersion","Basic probability"]
      ]},
      {name:"Digital Electronics", code:"BCA-104", units:[
        ["Number Systems and Codes","Binary and hexadecimal numbers","Conversions and arithmetic","BCD and Gray code","ASCII and Unicode overview"],
        ["Logic Gates","AND, OR and NOT gates","NAND and NOR gates","XOR and XNOR gates","Truth tables"],
        ["Boolean Algebra","Boolean laws and identities","De Morgan's theorems","Boolean expressions","Karnaugh map basics"],
        ["Combinational Circuits","Half and full adders","Subtractor circuits","Multiplexers and demultiplexers","Encoders and decoders"]
      ]}
    ],
    "2": [
      {name:"Data Structures", code:"BCA-201", units:[["Introduction","Data types and data structures","Linear and non-linear structures","Time and space complexity"],["Stacks and Queues","Stack operations","Applications of stacks","Queue operations","Circular queue"],["Linked Lists","Singly linked lists","Doubly linked lists","Circular linked lists","Insertion and deletion"],["Trees and Graphs","Tree terminology","Binary trees","Tree traversals","Graph basics"]]},
      {name:"Object Oriented Programming", code:"BCA-202", units:[["OOP Concepts","Classes and objects","Encapsulation and abstraction","Inheritance and polymorphism"],["Language Basics","Data types and operators","Control statements","Arrays and strings"],["Classes","Constructors and destructors","Access specifiers","Static members","Friend functions"],["Advanced OOP","Function overloading","Operator overloading","Inheritance types","Exception handling"]]},
      {name:"Database Management Systems", code:"BCA-203", units:[["DBMS Basics","Database concepts","DBMS architecture","Data models","Database users"],["Relational Model","Tables, rows and columns","Keys and constraints","Relational algebra","ER diagrams"],["SQL","DDL and DML commands","SELECT queries","Joins and subqueries","Aggregate functions"],["Database Design","Functional dependencies","Normalization","Transactions","Backup and recovery"]]},
      {name:"Mathematics II", code:"BCA-204", units:[["Discrete Mathematics","Propositions and logic","Truth tables","Predicate logic"],["Relations and Functions","Equivalence relations","Partial orders","Functions and composition"],["Graph Theory","Types of graphs","Paths and circuits","Trees and spanning trees"],["Numerical Methods","Errors and approximations","Bisection method","Newton-Raphson method","Interpolation basics"]]}
    ]
  },
  "2": {
    "3": [
      {name:"Operating Systems", code:"BCA-301", units:[["Introduction","Operating system concepts and functions","Types of operating systems","System calls","Operating system structures"],["Process Management","Process states and PCB","CPU scheduling","Threads","Process synchronization"],["Memory Management","Contiguous memory allocation","Paging and segmentation","Virtual memory","Page replacement concepts"],["File and Device Management","File system concepts","Directory structures","I/O management","Deadlocks overview"]]},
      {name:"Java Programming", code:"BCA-302", units:[["Java Fundamentals","Features of Java and JVM","Structure of a Java program","Data types and operators","Control statements"],["Object Oriented Java","Classes and objects","Constructors and methods","Inheritance","Polymorphism and interfaces"],["Exception and Packages","Exception handling","try, catch and finally","Packages and access control","Multithreading basics"],["Collections and GUI","Collection framework overview","ArrayList and HashMap","AWT and Swing basics","Event handling"]]},
      {name:"Computer Networks", code:"BCA-303", units:[["Network Fundamentals","Network types and topologies","Network devices","OSI reference model","TCP/IP model"],["Physical and Data Link Layers","Transmission media","Signal and encoding basics","Framing and error detection","Ethernet basics"],["Network Layer","IP addressing","IPv4 and IPv6","Routing concepts","Subnetting basics"],["Transport and Application Layers","TCP and UDP","DNS and DHCP","HTTP and HTTPS","Email protocols"]]},
      {name:"Python Programming", code:"BCA-304", units:[["Python Basics","Features and installation overview","Variables and data types","Operators and expressions","Input and output"],["Control Flow","Conditional statements","Loops","break, continue and pass","Comprehensions"],["Data Structures","Lists and tuples","Sets and dictionaries","Strings and methods","Slicing"],["Functions and Modules","Defining functions","Arguments and return values","Modules and packages","File handling and exceptions"]]}
    ],
    "4": [
      {name:"Software Engineering", code:"BCA-401", units:[["Introduction","Software characteristics","Software process models","SDLC overview","Agile methodology"],["Requirement Analysis","Requirement types","Feasibility study","SRS document","Use case diagrams"],["Design and Testing","Software design principles","UML overview","Testing levels","Black-box and white-box testing"],["Project Management","Cost estimation basics","Scheduling and risk management","Software quality","Maintenance"]]},
      {name:"Web Technology", code:"BCA-402", units:[["HTML","HTML document structure","Text, links and images","Tables and forms","Semantic HTML"],["CSS","Selectors and properties","Box model","Flexbox and Grid","Responsive design"],["JavaScript","Variables and data types","Functions and events","DOM manipulation","Arrays and objects"],["Web and Server Basics","Client-server architecture","HTTP methods and status codes","Web hosting concepts","Web security basics"]]},
      {name:"Computer Graphics", code:"BCA-403", units:[["Graphics Fundamentals","Applications of computer graphics","Raster and vector displays","Graphics input devices","Coordinate systems"],["Drawing Algorithms","Line drawing concepts","DDA algorithm","Bresenham line algorithm","Circle drawing concepts"],["2D Transformations","Translation","Scaling","Rotation","Reflection and shearing"],["3D Graphics","3D coordinate systems","Projection concepts","Visible surface detection","Animation basics"]]},
      {name:"E-Commerce", code:"BCA-404", units:[["Introduction","E-commerce concepts and scope","Business models","Traditional vs electronic commerce","E-commerce architecture"],["E-Commerce Technologies","Internet and intranet","Electronic data interchange","Online marketplaces","Mobile commerce"],["Payments and Security","Electronic payment systems","Payment gateways","Digital signatures","Security and privacy"],["Applications and Issues","Online retailing","Digital marketing basics","Legal and ethical issues","Emerging trends"]]}
    ]
  }
};

const STORAGE_KEY = "shivansh-bca-checklist-v1";
let progress = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
let year = "1", semester = "1", activeSubject = 0, filter = "all";
const $ = id => document.getElementById(id);
const allSubjects = () => syllabus[year][semester] || [];
const keyFor = (s,u,t) => `${year}-${semester}-${s}-${u}-${t}`;
const isDone = (s,u,t) => !!progress[keyFor(s,u,t)];
const allTopics = () => allSubjects().flatMap((s,si)=>s.units.flatMap((unit,ui)=>unit.slice(1).map((topic,ti)=>({si,ui,ti:ti+1,topic}))));
const totals = () => { const a=allTopics(); const done=a.filter(x=>isDone(x.si,x.ui,x.ti)).length; return {done,total:a.length,left:a.length-done,pct:a.length?Math.round(done/a.length*100):0}; };

function saveLocal(){ localStorage.setItem(STORAGE_KEY,JSON.stringify(progress)); $("saveState").innerHTML="<i></i> Saved on this device"; }
function toast(msg){const el=$("toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2300);}
function renderSemesterOptions(){const sems=Object.keys(syllabus[year]);$("semesterSelect").innerHTML=sems.map(s=>`<option value="${s}">Semester ${s}</option>`).join("");semester=sems[0];activeSubject=0;}
function renderOverall(){const t=totals();$("overallPercent").textContent=t.pct+"%";$("overallCount").textContent=`${t.done} / ${t.total} topics`;$("overallBar").style.width=t.pct+"%";$("doneCount").textContent=t.done+" completed";$("leftCount").textContent=t.left+" remaining";}
function renderSubjects(){const subjects=allSubjects();$("subjectTotal").textContent=subjects.length;$("subjectNav").innerHTML=subjects.map((s,i)=>{const count=s.units.reduce((n,u)=>n+u.length-1,0);let done=0;s.units.forEach((u,ui)=>u.slice(1).forEach((_,ti)=>{if(isDone(i,ui,ti+1))done++}));return `<button class="subject-item ${i===activeSubject?"active":""}" data-subject="${i}"><span class="subject-icon">${String(i+1).padStart(2,"0")}</span><span class="subject-label">${s.name}</span><span class="subject-mini">${count?Math.round(done/count*100):0}%</span></button>`}).join("");$("subjectNav").querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>{activeSubject=Number(b.dataset.subject);renderSubjects();renderTopics()}));}
function renderTopics(){const s=allSubjects()[activeSubject];if(!s)return;$("subjectCode").textContent=s.code;$("subjectTitle").textContent=s.name;$("subjectSubtitle").textContent="Work through each unit and tick topics as you complete them.";let count=0,done=0;s.units.forEach((u,ui)=>u.slice(1).forEach((_,ti)=>{count++;if(isDone(activeSubject,ui,ti+1))done++}));const pct=count?Math.round(done/count*100):0;$("subjectPercent").textContent=pct+"%";$("subjectBar").style.width=pct+"%";
 const q=$("searchInput").value.trim().toLowerCase();let html="",shown=0;
 s.units.forEach((u,ui)=>u.slice(1).forEach((topic,ti)=>{const checked=isDone(activeSubject,ui,ti+1);if(q&&!topic.toLowerCase().includes(q))return;if(filter==="done"&&!checked)return;if(filter==="pending"&&checked)return;shown++;html+=`<label class="topic-row ${checked?"done":""}"><input class="topic-check" type="checkbox" data-unit="${ui}" data-topic="${ti+1}" ${checked?"checked":""}><span class="topic-name">${escapeHtml(topic)}</span><span class="unit-tag">UNIT ${ui+1}</span></label>`}));
 $("topicList").innerHTML=html||'<div class="empty-state">No topics match this filter.</div>';$("visibleCount").textContent=`Showing ${shown} of ${count} topics`;
 $("topicList").querySelectorAll("input").forEach(cb=>cb.addEventListener("change",()=>{progress[keyFor(activeSubject,Number(cb.dataset.unit),Number(cb.dataset.topic))]=cb.checked;saveLocal();renderAll();if(currentUser)syncCloud();}));
}
function escapeHtml(str){return str.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function renderAll(){renderOverall();renderSubjects();renderTopics();}
$("yearSelect").addEventListener("change",e=>{year=e.target.value;renderSemesterOptions();$("searchInput").value="";filter="all";document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b.dataset.filter==="all"));renderAll()});
$("semesterSelect").addEventListener("change",e=>{semester=e.target.value;activeSubject=0;$("searchInput").value="";renderAll()});
$("searchInput").addEventListener("input",renderTopics);
document.querySelectorAll(".filter").forEach(b=>b.addEventListener("click",()=>{filter=b.dataset.filter;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderTopics()}));
$("resetBtn").addEventListener("click",()=>{if(confirm("Reset all your saved topic progress on this device?")){progress={};saveLocal();renderAll();if(currentUser)syncCloud();toast("Progress reset.")}});
$("loginBtn").addEventListener("click",async()=>{if(!firebaseReady){toast("Add your Firebase config in app.js to enable Google Login.");return;}try{await signInWithPopup(auth,new GoogleAuthProvider())}catch(e){console.error(e);toast("Google sign-in could not be completed.")}});
$("logoutBtn").addEventListener("click",async()=>{if(auth)await signOut(auth)});
async function syncCloud(){if(!currentUser||!db)return;try{await setDoc(doc(db,"studentProgress",currentUser.uid),{progress,displayName:currentUser.displayName||"",email:currentUser.email||"",updatedAt:new Date().toISOString()},{merge:true});$("saveState").innerHTML="<i></i> Synced to cloud"}catch(e){console.error(e);$("saveState").innerHTML="<i></i> Saved on this device";toast("Cloud sync failed. Check Firestore rules.")}}
if(firebaseReady){onAuthStateChanged(auth,async user=>{currentUser=user;if(user){$("loginBtn").classList.add("hidden");$("profileBox").classList.remove("hidden");$("profileName").textContent=user.displayName||"Student";if(user.photoURL){$("profilePic").src=user.photoURL;$("profilePic").classList.remove("hidden")}try{const snap=await getDoc(doc(db,"studentProgress",user.uid));if(snap.exists()){progress={...progress,...(snap.data().progress||{})};saveLocal();renderAll()}await syncCloud();toast("Signed in. Progress sync is on.")}catch(e){console.error(e);toast("Signed in, but cloud data could not load.")}}else{$("loginBtn").classList.remove("hidden");$("profileBox").classList.add("hidden")}})}
renderSemesterOptions();renderAll();
